from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

app = Flask(__name__)
#==================== Configuración del Servidor ====================
usuario_bd = 'root'
password_bd = 'Rd-3124170648'
servidor_bd = 'localhost'
puerto_bd = '3306'
nombre_bd = 'based'

#==================== Configurar base de datos ====================
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{usuario_bd}:{password_bd}@{servidor_bd}:{puerto_bd}/{nombre_bd}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

#==================== Inicializar DB y Marshmallow ====================
db = SQLAlchemy(app)
ma = Marshmallow(app)

class Evento(db.Model): #Se crea clase la cual permite generar la Tabla Categoria
    #Model: Esta variable sirve para crear el modelo de Base de Datos
    __tablename__ = "Evento" #Esta variable me permite nombrar la tabla a crear

    id_Evento = db.Column(db.Integer, primary_key=True) #Se genera el campo que contiene nuestra llave primaria
    titulo = db.Column(db.String(255)) #Se genera campo nombre
    descripcion = db.Column(db.String(255)) #Se genera campo descripción
    imagen = db.Column(db.String(255))

    def __init__(self, titulo, descripcion, imagen): #Se crea función constructora de la clase, que permite especificar los atributos del objeto
        #self: Es una referencia a la instancia actual de una clase. Es el primer parámetro en los métodos de una clase
        self.titulo = titulo
        self.descripcion = descripcion
        self.imagen = imagen

#=============================      CATEGORIAS      =============================

#Esquema Tabla Categoria
class EventoSchema(ma.SQLAlchemyAutoSchema): #Se genera el esquema, es decir cuando se hace una consulta el 
    #esquema lo que me identifica es los datos
    class Meta: #Subclase que realiza la configuración del esquema
        model = Evento
        load_instance = True

#Esquemas para cuando es un dato y otro para varios.
Evento_schema = EventoSchema() #Esquema de respuesta cuando es un elemento
Eventos_schema = EventoSchema(many=True) #Esquema de respuesta cuando son todos los elementos

#GET
@app.route('/Evento', methods = ['GET']) #Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def get_Eventos():
    all_Eventos = Evento.query.all() #Función que permite traer todos los registros de la consulta
    result = Eventos_schema.dump(all_Eventos) #Genera un diccionario con los elementos traídos de la consulta (Organiza la información)
    return jsonify(result) #Estructura la respuesta en formato JSON

#GET x ID
@app.route('/Evento/<id>', methods = ['GET']) #Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
                                            #<id> identifica lo que se envíe por URL después del / corresponde a la variable id
def get_EventoID(id): #Se recibe la variable que se especificó en el route por método GET
    una_Evento = Evento.query.get(id) #Función que permite realizar la consulta por la llave primaria, trae un elemento
    return Evento_schema.jsonify(una_Evento) #Estructura la respuesta en formato JSON

#POST
@app.route('/Evento', methods = ['POST']) #Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def insert_Evento():
    data = request.get_json(force=True) #Al ser por método POST internamente en la variable request se trae la
                                        #información que se especificó en el cliente. En este caso la que se envía por POSTMAN

    titulo = data['titulo'] #Variables que se traen en el request
    descripcion = data['descripcion'] #Variables que se traen en el request
    imagen = data['imagen']

    nueva_Evento = Evento(titulo, descripcion, imagen) #Se genera objeto tipo categoria para ser almacenada en la tabla

    db.session.add(nueva_Evento) #Se especifica el tipo de sentencia en SQL que se hará (INSERT TO)
    db.session.commit() #Se ejecuta la sentencia
    return Evento_schema.jsonify(nueva_Evento) #Se presenta la información que se almacenó en formato JSON

#PUT
@app.route('/Evento/<id>', methods = ['PUT']) #Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def update_Evento(id): #Se recibe la variable que se especificó en el route
    data = request.get_json(force=True) #Al ser por método PUT internamente en la variable request se trae la
                                        #información que se especificó en el cliente. En este caso la que se envía por POSTMAN
    actualizar_Evento = Evento.query.get(id) #Función que permite realizar la consulta por la llave primaria, trae un elemento
    titulo = data['titulo'] #Variables que se traen en el request
    descripcion = data['descripcion'] #Variables que se traen en el request
    imagen = data['imagen']

    actualizar_Evento.titulo = titulo #Se actualiza la información del elemento
    actualizar_Evento.descripcion = descripcion #Se actualiza la información del elemento
    actualizar_Evento.imagen = imagen
    db.session.commit() #Se ejecuta la sentencia

    return Evento_schema.jsonify(actualizar_Evento) #Se presenta la información que se almacenó en formato JSON

#DELETE
@app.route('/Evento/<id>', methods = ['DELETE']) #Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def delete_Evento(id): #Se recibe la variable que se especificó en el route
    eliminar_Evento = Evento.query.get(id) #Función que permite realizar la consulta por la llave primaria, trae un elemento

    db.session.delete(eliminar_Evento) #Se especifica el tipo de sentencia en SQL que se hará (DELETE)
    db.session.commit() #Se ejecuta la sentencia
    return Evento_schema.jsonify(eliminar_Evento) #Se presenta la información que se almacenó en formato JSON

#==================== Ejecutar servidor ====================
if __name__ == '__main__':
    with app.app_context():
        db.create_all() 
        app.run(debug=True)