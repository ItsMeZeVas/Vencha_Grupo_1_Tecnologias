from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS
#==================== Configuración del Servidor ====================
usuario_bd = 'root'
password_bd = 'felipeumng25.'
servidor_bd = 'localhost'
puerto_bd = '3306'
nombre_bd = 'eventos_colombianos'

app = Flask(__name__) 
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{usuario_bd}:{password_bd}@{servidor_bd}:{puerto_bd}/{nombre_bd}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#==================== Inicializar DB y Marshmallow ====================
db = SQLAlchemy(app)
ma = Marshmallow(app)
#======================================================================

class Carnaval(db.Model):
    __tablename__ = "carnaval"

    id_carnaval = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(255))
    descripcion = db.Column(db.String(5000))
    imagen_url = db.Column(db.String(255))

    def __init__(self, titulo, descripcion, imagen_url): 
        self.titulo = titulo
        self.descripcion = descripcion
        self.imagen_url = imagen_url

###################################          CATEGORIAS          ###################################

class CarnavalSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Carnaval
        load_instance = True

carnaval_schema = CarnavalSchema()
carnavales_schema = CarnavalSchema(many=True)

# GET
@app.route('/carnaval', methods=['GET'])
def get_carnavales():
    all_carnavales = Carnaval.query.all()
    result = carnavales_schema.dump(all_carnavales)
    return jsonify(result)

# GET x ID
@app.route('/carnaval/<id>', methods=['GET'])
def get_carnavalID(id):
    un_carnaval = Carnaval.query.get(id)
    return carnaval_schema.jsonify(un_carnaval)

# POST
@app.route('/carnaval', methods=['POST'])
def insert_carnaval():
    data = request.get_json(force=True)
    titulo = data['titulo']
    descripcion = data['descripcion']
    imagen_url = data['imagen_url']

    nuevo_carnaval = Carnaval(titulo, descripcion, imagen_url)

    db.session.add(nuevo_carnaval)
    db.session.commit()
    return carnaval_schema.jsonify(nuevo_carnaval)

# PUT
@app.route('/carnaval/<id>', methods=['PUT']) 
def update_carnaval(id):  
    data = request.get_json(force=True) 

    actualizar_carnaval = Carnaval.query.get(id)  

    titulo = data['titulo']  
    descripcion = data['descripcion'] 
    imagen_url = data['imagen_url']  


    actualizar_carnaval.titulo = titulo
    actualizar_carnaval.descripcion = descripcion
    actualizar_carnaval.imagen_url = imagen_url

    db.session.commit()  

    return carnaval_schema.jsonify(actualizar_carnaval) 

# DELETE
@app.route('/carnaval/<id>', methods=['DELETE'])  
def delete_carnaval(id):  
    eliminar_carnaval = Carnaval.query.get(id) 

    db.session.delete(eliminar_carnaval) 
    db.session.commit() 

    return carnaval_schema.jsonify(eliminar_carnaval) 

@app.route('/', methods=['GET'])
def root():
    return jsonify({'mensaje': 'Bienvenido'})

#==================== Ejecutar servidor ====================
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.run(debug=True)