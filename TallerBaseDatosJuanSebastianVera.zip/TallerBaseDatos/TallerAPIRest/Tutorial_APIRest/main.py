from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS

#==================== Configuración del Servidor ====================
usuario_bd = 'root'
password_bd = 'ContraUni09*'
servidor_bd = 'localhost'
puerto_bd = '3306'
nombre_bd = 'basededatosprueba'

app = Flask(__name__)
CORS(app)  # Permite el acceso a la API desde cualquier origen (CORS)

app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{usuario_bd}:{password_bd}@{servidor_bd}:{puerto_bd}/{nombre_bd}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#==================== Inicializar DB y Marshmallow ====================
db = SQLAlchemy(app)
ma = Marshmallow(app)
#======================================================================

class Fiesta(db.Model):
    
    __tablename__ = "Fiesta"

    id_fiesta = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(255))
    descripcion = db.Column(db.String(5000))
    imagen_url = db.Column(db.String(255))

    def __init__(self, titulo, descripcion,imagen_url):  # Se crea función constructora de la clase, que permite especificar los atributos del objeto
        # self: Es una referencia a la instancia actual de una clase. Es el primer parámetro en los métodos de una clase
        self.titulo = titulo
        self.descripcion = descripcion
        self.imagen_url = imagen_url


###################################          FIESTAS         ###################################
#Esquema Tabla Fiestas
class FiestaSchema(ma.SQLAlchemyAutoSchema):  # Se genera el esquema, es decir cuando se hace una consulta el
                                                 # esquema lo que me identifica es los datos
    class Meta:  # Subclase que realiza la configuración del esquema
        model = Fiesta
        load_instance = True

fiesta_schema = FiestaSchema()  # Esquema de respuesta cuando es un elemento
fiestas_schema = FiestaSchema(many=True)  # Esquema de respuesta cuando son todos los elementos

# GET
@app.route('/fiesta', methods = ['GET'])  # Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def get_fiestas():
    all_fiestas = Fiesta.query.all()  # Función que permite traer todos los registros de la consulta
    result = fiestas_schema.dump(all_fiestas)  # Genera un diccionario con los elementos traídos de la consulta (Organiza la información)
    return jsonify(result)  # Estructura la respuesta en formato JSON

# GET x ID
@app.route('/fiesta/<id>', methods = ['GET'])  # Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
                                                # <id> identifica que lo que se envíe por URL después del / corresponde a la variable id
def get_fiestaID(id):  # Se recibe la variable que se especificó en el route por método GET
    una_fiesta = Fiesta.query.get(id)  # Función que permite realizar la consulta por la llave primaria, trae un elemento
    return fiesta_schema.jsonify(una_fiesta)  # Estructura la respuesta en formato JSON

# POST
@app.route('/fiesta', methods = ['POST'])  # Se especifica la URL que debe ser ingresada para ejecutar la función que se encuentra abajo
def insert_fiesta():
    data = request.get_json(force=True)  # Al ser por método POST internamente en la variable request se trae la información que se especificó en el cliente. En este caso la que se envía por POSTMAN
    titulo = data['titulo']  # Variables que se traen en el request
    descripcion = data['descripcion']  # Variables que se traen en el request
    imagen_url = data['imagen_url'] # Variables que se traen en el request
    
    nueva_fiesta = Fiesta(titulo, descripcion, imagen_url)  # Se genera objeto tipo categoria para ser almacenada en la tabla


    db.session.add(nueva_fiesta)  # Se especifica el tipo de sentencia en SQL que se hará (INSERT INTO)
    db.session.commit()  # Se ejecuta la sentencia
    return fiesta_schema.jsonify(nueva_fiesta)  # Se presenta la información que se almacenó en formato JSON

# PUT
@app.route('/fiesta/<id>', methods=['PUT'])  # Se especifica la URL para actualizar una fiesta específica
def update_fiesta(id):  # Se recibe el ID desde la URL
    data = request.get_json(force=True)  # Obtiene los datos enviados en el cuerpo de la solicitud

    actualizar_fiesta = Fiesta.query.get(id)  # Consulta por ID en la base de datos

    titulo = data['titulo']  # Extrae el título del request
    descripcion = data['descripcion']  # Extrae la descripción
    imagen_url = data['imagen_url']  # Extrae la URL de imagen

    # Se actualizan los campos
    actualizar_fiesta.titulo = titulo
    actualizar_fiesta.descripcion = descripcion
    actualizar_fiesta.imagen_url = imagen_url

    db.session.commit()  # Guarda los cambios

    return fiesta_schema.jsonify(actualizar_fiesta)  # Retorna la fiesta actualizada en formato JSON

# DELETE
@app.route('/fiesta/<id>', methods=['DELETE'])  # Se especifica la URL que debe ser ingresada para ejecutar la función
def delete_fiesta(id):  # Se recibe la variable que se especificó en el route
    eliminar_fiesta = Fiesta.query.get(id)  # Función que permite realizar la consulta por la llave primaria, trae un elemento

    db.session.delete(eliminar_fiesta)  # Se especifica el tipo de sentencia en SQL que se hará (DELETE)
    db.session.commit()  # Se ejecuta la sentencia

    return fiesta_schema.jsonify(eliminar_fiesta)  # Se presenta la información que se eliminó en formato JSON
@app.route('/', methods = ['GET']) # Se le indica al sistema que ejecutar una vez entre en el navegador la url raíz
def root():
    return jsonify({'$mensaje':'Bienvenido'})

#==================== Ejecutar servidor ====================
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Crea las tablas si no existen
        app.run(debug=True)