from flask import Flask, jsonify
from flask_mysqldb import MySQL
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Configuración MySQL
app.config['MYSQL_HOST'] = '127.0.0.1:5000'
app.config['MYSQL_USER'] = 'SebasVera'
app.config['MYSQL_PASSWORD'] = 'ContraUni09*'
app.config['MYSQL_DB'] = 'eventos'

mysql = MySQL(app)

@app.route('/api/cards', methods=['GET'])
def get_cards():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT titulo, descripcion, imagen_url FROM cards")
    data = cursor.fetchall()
    cursor.close()

    cards = [{'titulo': row[0], 'descripcion': row[1], 'imagen': row[2]} for row in data]
    return jsonify(cards)

if __name__ == '__main__':
    app.run(debug=True)
